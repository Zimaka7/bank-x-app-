package com.bankz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankZSimpleApplication {
    public static void main(String[] args) {
        SpringApplication.run(BankZSimpleApplication.class, args);
    }
}